export interface Kasutaja {
  id: number,
  e_meil: string,
  parool: string,
  token: string,
}
