export interface Koondaruanne {
  seisundi_kood: String,
  nimetus: String,
  laadimispunktide_arv: String,
}
