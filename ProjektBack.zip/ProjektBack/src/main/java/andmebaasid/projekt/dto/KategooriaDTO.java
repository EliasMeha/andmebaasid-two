package andmebaasid.projekt.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class KategooriaDTO {

    private String kategooriaNimetus;

    private String kategooriaTyypNimetus;
}
